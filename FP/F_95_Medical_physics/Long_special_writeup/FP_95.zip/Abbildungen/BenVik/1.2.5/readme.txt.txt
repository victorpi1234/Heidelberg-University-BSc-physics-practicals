All Eche times (TE) were set to 35, except if it was specified otherwise in the file names
fpPraktikum
